//
//  main.m
//  primeiraAtiv
//
//  Created by Humberto  Julião on 05/02/15.
//  Copyright (c) 2015 Humberto  Julião. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Pessoa.h"
#import "Empregado.h"


int main(int argc, const char * argv[]) {
    @autoreleasepool {
//        Pessoa *teste=[[Pessoa alloc] init];
//        [teste setAnoNasc:1995];
//        [teste setDiaNasc:1];
//        [teste setMesNasc:1];
//        [teste setNome:@"Manoel"];
//        [teste imprimeNome];
        Empregado *func1=[[Empregado alloc] initWithNome:@"Manoel" eSobrenome:@"sad" eSalario:500.0];
        Empregado *func2=[[Empregado alloc] initWithNome:@"Manoel" eSobrenome:@"happy" eSalario:5000.0];
        [func1 salarioAnual];
        [func2 salarioAnual];
        [func1 aumento:10];
        [func2 aumento:10];
        [func1 salarioAnual];
        [func2 salarioAnual];
    }
    return 0;
}
