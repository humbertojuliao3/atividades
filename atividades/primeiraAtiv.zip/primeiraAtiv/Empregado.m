//
//  Empregado.m
//  primeiraAtiv
//
//  Created by Humberto  Julião on 04/02/15.
//  Copyright (c) 2015 Humberto  Julião. All rights reserved.
//

#import "Empregado.h"

@implementation Empregado
@synthesize nome,sobrenome,salarioMes;
-(instancetype) initWithNome:(NSString *)nomeI eSobrenome:(NSString *)sobreNI eSalario:(double)sal
{
    self = [super init];
    if (self) {
        nome=nomeI;
        sobrenome=sobreNI;
        if (sal<0) {
            salarioMes=0.0;
        }else{
            salarioMes=sal;}
    }
    return self;
}
-(void) salarioAnual
{
    NSLog(@"salario anual de %f reais",(salarioMes*=12));
}
-(void) aumento:(int)valor
{
    salarioMes=salarioMes+(salarioMes*(valor/100));
}

@end
