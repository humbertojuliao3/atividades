//
//  Pessoa.h
//  primeiraAtiv
//
//  Created by Humberto  Julião on 04/02/15.
//  Copyright (c) 2015 Humberto  Julião. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Pessoa : NSObject
{
    NSString *nome;
    int diaNasc;
    int mesNasc;
    int anoNasc;
}
@property NSString *nome;
@property int diaNasc;
@property int mesNasc;
@property int anoNasc;

-(int) idade;
-(NSString *) verificaIdade;
-(void) imprimeNome;
//-(void) calculaIdadeComDia:(int) dia eMes:(int) mes eAno: (int)ano;

@end
