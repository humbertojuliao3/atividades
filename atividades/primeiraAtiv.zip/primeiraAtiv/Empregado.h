//
//  Empregado.h
//  primeiraAtiv
//
//  Created by Humberto  Julião on 04/02/15.
//  Copyright (c) 2015 Humberto  Julião. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Empregado : NSObject
{
    NSString *nome;
    NSString *sobrenome;
    double salarioMes;
}
@property NSString *nome;
@property NSString *sobrenome;
@property double salarioMes;

-(instancetype) initWithNome:(NSString *)nomeI eSobrenome:(NSString *)sobreNI eSalario:(double)sal;
-(void) aumento:(int)valor;
-(void) salarioAnual;

@end
