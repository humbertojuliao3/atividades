//
//  Pessoa.m
//  primeiraAtiv
//
//  Created by Humberto  Julião on 04/02/15.
//  Copyright (c) 2015 Humberto  Julião. All rights reserved.
//

#import "Pessoa.h"

@implementation Pessoa
@synthesize nome, diaNasc,mesNasc,anoNasc;
- (int) idade;
{
    return 2015-anoNasc;
}
-(NSString *) verificaIdade;
{
    NSString *result;
    if ([self idade]>= 18) {
        result=@"é maior de idade";
    }else{
        result=@"não é maior de idade";
    }
    return result;
}
-(void)imprimeNome
{
    NSLog(@"Este é %@", nome);
    NSLog(@"%i",[self idade]);
    NSLog(@"%@",[self verificaIdade]);
}


@end
