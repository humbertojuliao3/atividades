//
//  Funcionario.h
//  Atividade2
//
//  Created by Humberto  Julião on 05/02/15.
//  Copyright (c) 2015 Humberto  Julião. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Funcionario : NSObject
{
    double salarioBase;
    
}
@property double salarioBase;
-(double) obterPagamento;
-(void) definirSalariocom:(double) salario;
-(double) obterSalarioBase;
@end
