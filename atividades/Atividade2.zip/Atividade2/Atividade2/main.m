//
//  main.m
//  Atividade2
//
//  Created by Humberto  Julião on 05/02/15.
//  Copyright (c) 2015 Humberto  Julião. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Funcionario.h"
#import "Vendedor.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
//        Funcionario *teste1=[[Funcionario alloc] init];
//        Vendedor *testeV=[[Vendedor alloc] init];
//        [teste1 setSalarioBase:500.0];
//        [testeV setSalarioBase:500.0];
//        [testeV setComissao:50];
//        NSLog(@"teste1 salario de %f reais",[teste1 obterPagamento]);
//        NSLog(@"testeV salario de %f reais",[testeV obterPagamento]);
        
    }
    return 0;
}
