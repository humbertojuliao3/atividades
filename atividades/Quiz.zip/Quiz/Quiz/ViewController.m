//
//  ViewController.m
//  Quiz
//
//  Created by Humberto  Julião on 23/02/15.
//  Copyright (c) 2015 Humberto  Julião. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize pergunta,resposta,perg,resp,respImage;
int iresp=0;
int iperg=0;

- (void)viewDidLoad {
    [super viewDidLoad];
    perg=@[@"quem é esse pokemon?",@"quanto é 2+2?",@"o que que eu tenho no bolso?"];
    resp=@[@"é o Charlizard",@"4",@"O Um Anel!!!"];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)mostrarPergunta:(id)sender {
    [pergunta setText:perg[iperg]];
    [resposta setText:@"???"];
    if (iperg<2) {
//        [respImage setImage:];
        iperg++;
    }else{
        iperg=0;}
    
    
}

- (IBAction)mostrarResposta:(id)sender {
    [resposta setText:resp[iresp]];
    
    if (iresp<2) {
        iresp++;
    }else{
        iresp=0;}
}
@end
